# **App Name**: Campus Gigs

## Core Features:

- Job Posting: Enable employers to post part-time jobs with detailed descriptions (category, location, pay, duration, etc.).
- Job Search: Enable students to browse/search jobs near them based on category, location, and pay.
- Application Tracking: Allow students to apply for jobs and track their application status.
- Applicant Management: Allow employers to view applicants and approve/hire students.
- Job Recommendation: AI-powered tool to generate personalized job recommendations for students based on their skills and location.
- In-App Messaging: Optional chat feature for employers and students to communicate.
- User Authentication: Simple authentication system to register/login employers and students.

## Style Guidelines:

- Primary color: A warm yellow (#FFC107) to convey optimism and energy, fitting for students starting new jobs.
- Background color: A light, desaturated yellow (#FAF8EF) provides a gentle backdrop.
- Accent color: A complementary orange (#FF9800) highlights calls to action.
- Font pairing: 'Space Grotesk' (sans-serif) for headlines, 'Inter' (sans-serif) for body text
- Clean, modern icons for job categories and app functions.
- Simple, card-based layout for job listings. Intuitive navigation.
- Subtle animations when updating application status.